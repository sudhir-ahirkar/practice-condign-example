package com.CognisTest;

public class Test2 {

    public static void main(String[] args) {
       /* int i;
        do{
            i++;
        }while(i<0);
        System.out.println(i);*/
    }
}
//output==> Error:(8, 13) java: variable i might not have been initialized